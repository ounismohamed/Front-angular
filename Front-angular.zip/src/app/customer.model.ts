
export interface customer {
    firstname:  String;
    lastname: String;
    address:  String;  
    city:  String;
    state:  String;
    ordertotal:string;
    }